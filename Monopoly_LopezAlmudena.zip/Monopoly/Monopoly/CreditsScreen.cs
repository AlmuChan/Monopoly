﻿/*
 * Almudena López Sánchez 2018
 * 
 * 0.01, 21-May-2018: Create class
 */

class CreditsScreen : Screen
{
    public CreditsScreen(Hardware hardware) : base(hardware)
    {
        //TO DO
    }

    public override void Run()
    {
        //TO DO
    }
}

