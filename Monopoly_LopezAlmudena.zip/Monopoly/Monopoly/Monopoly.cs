﻿/*
 * Almudena López Sánchez 
 * 
 * 0.01, 14-May-2018: Create class
 */

class Program
{
    static void Main(string[] args)
    {
        GameController gameC = new GameController();
        gameC.Run();
    }
}

